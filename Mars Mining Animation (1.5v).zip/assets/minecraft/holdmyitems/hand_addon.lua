local player = context.player
local item = context.item
local matrices = context.matrices
local mainHand = context.mainHand
local blockBreaking = context.blockBreaking
local deltaTime = context.deltaTime

global.breakAnimation = global.breakAnimation or 0
global.crouchTimer = global.crouchTimer or 0

if P:isSneaking(player) then
    global.crouchTimer = global.crouchTimer + deltaTime * 6
else
    global.crouchTimer = global.crouchTimer - deltaTime * 6
end

local crouchRotate = M:sin(global.crouchTimer) * 10

if blockBreaking then
    global.breakAnimation = global.breakAnimation + 0.01
else
    global.breakAnimation = global.breakAnimation * 0.9
end

local A = 50 + 20 * M:abs(M:sin(global.breakAnimation / 2))
local B = 5
local C = 3

local mainSwing = A * M:sin(global.breakAnimation) * M:abs(M:sin(global.breakAnimation))
local microSwing = B * M:sin(global.breakAnimation * 2)
local sway = C * M:sin(global.breakAnimation / 3)

global.breakAnimation = M:clamp(global.breakAnimation, 0, 5)

local angle = mainSwing + microSwing

if mainHand then
    if blockBreaking and I:isIn(item, Tags:getVanillaTag("pickaxes")) and P:isSneaking(player) then
        M:rotateZ(matrices, angle / 2.5)
        M:moveY(matrices, 0.4)
        M:rotateZ(matrices, crouchRotate)
    end
end