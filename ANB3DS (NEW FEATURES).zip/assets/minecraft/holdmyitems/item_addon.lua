
function easeOutBack(t, back, speed)
    back = back or 1.70158
    speed = speed or 1.0
    t = math.min(math.max(t * speed, 0), 1)
    t = t - 1
    return (t * t * ((back + 1) * t + back) + 1)
end

function easeCustom(t)
    local t2 = t * t
    local t3 = t2 * t
    return 3 * t * (1 - t) * (1 - t) * 0.44 +
            3 * t2 * (1 - t) * 1 +
            t3
end

function easeCustomSec(t)
	local t2 = t * t
	local t3 = t2 * t
	return 3 * t * (1 - t) * (1 - t) * 0.44 +
		3 * t2 * (1 - t) * 0.94 +
		t3
end

global.pitchAngle = 0.0;
global.yawAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngleO = 0.0;

local ptAngle = context.ptAngle or 0
local ywAngle = context.ywAngle or 0

local ywAngle = (context.mainHand and yawAngle) or yawAngleO
local ptAngle = (context.mainHand and pitchAngle) or pitchAngleO

local bl = context.bl
local item = context.item
local matrices = context.matrices
local player = context.player
local mainHand = context.mainHand
local deltaTime = context.deltaTime
local mainHandSwingProgress = context.mainHandSwingProgress
local swingMHand = context.swingMHand
local swingOHand = context.swingOHand
local particles = context.particles
local swingProgress = context.swingProgress
local equipProgress = context.equipProgress
local mainHandSwitchEvent = context.mainHandSwitchEvent
local offHandSwitchEvent = context.offHandSwitchEvent

local ptAngle = context.ptAngle or 0
local ywAngle = context.ywAngle or 0

local ywAngle = (context.mainHand and yawAngle) or yawAngleO
local ptAngle = (context.mainHand and pitchAngle) or pitchAngleO

if I:isOf(item, Items:get("minecraft:feather")) then
    M:rotateZ(matrices, 0)
    M:rotateY(matrices, 0)
    M:rotateX(matrices, 0)
    M:moveX(matrices, -0.008)
    M:moveY(matrices, 0.216)
    M:moveZ(matrices, 0.062)
    M:scale(matrices, 1, 1, 1)
end

if I:isOf(item, Items:get("minecraft:shulker_shell")) then
    M:rotateZ(matrices, 0)
    M:rotateY(matrices, 0)
    M:rotateX(matrices, 0)
    M:moveX(matrices, 0.0)
    M:moveY(matrices, 0.302)
    M:moveZ(matrices, 0.0)
    M:scale(matrices, 1, 1, 1)
end