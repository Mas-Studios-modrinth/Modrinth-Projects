local l = (data.bl and 1) or -1
local player = data.player
local item = data.item
local mainHand = data.mainHand

global.pitchAngle = 0.0;
global.yawAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngleO = 0.0;

local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO

if I:isOf(data.item, Items:get("minecraft:feather")) then
    animator:rotateX( 6, 47, M:clamp(P:getPitch(player) / 1, -25, 30) + ptAngle + ywAngle * 1, 0, 0.4, 0.505)
end