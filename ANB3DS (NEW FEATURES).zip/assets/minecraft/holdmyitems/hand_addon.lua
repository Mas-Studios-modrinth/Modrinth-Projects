local bl = context.bl
local item = context.item
local matrices = context.matrices
local player = context.player
local mainHand = context.mainHand
local deltaTime = context.deltaTime
local mainHandSwingProgress = context.mainHandSwingProgress
local swingMHand = context.swingMHand
local swingOHand = context.swingOHand
local swingProgress = context.swingProgress
local equipProgress = context.equipProgress
local mainHandSwitchEvent = context.mainHandSwitchEvent
local offHandSwitchEvent = context.offHandSwitchEvent

local l = (bl and 1) or -1

function easeOutBack(t, back, speed)
    back = back or 1.70158
    speed = speed or 1.0
    t = math.min(math.max(t * speed, 0), 1)
    t = t - 1
    return (t * t * ((back + 1) * t + back) + 1)
end

function easeCustomSec(t)
	local t2 = t * t
	local t3 = t2 * t
	return 3 * t * (1 - t) * (1 - t) * 0.44 +
		3 * t2 * (1 - t) * 0.94 +
		t3
end

-- leather-only detector
if I:isOf(item, Items:get("minecraft:leather")) then
    M:rotateX(matrices, 0)
    M:rotateZ(matrices, 0)
    M:moveY(matrices, 0.0)
    M:moveX(matrices, 0)
end

if I:isOf(item, Items:get("minecraft:shulker_shell")) then
    M:rotateX(matrices, 0)
    M:rotateZ(matrices, 0)
    M:moveY(matrices, 0.227)
    M:moveX(matrices, 0.093)
    M:moveZ(matrices, -0.023)
end