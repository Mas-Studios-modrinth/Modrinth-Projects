--this is how you get the entries
local player = context.player
local mat = context.matrices
local pSpeed = P:getSpeed(player)
local l = (context.bl and 1) or -1 --determine which hand to use
local pHealth = P:getHealth(player)

global.walk = global.walk or 0
global.walkSmoother = global.walkSmoother or 0

--adressing global thingies
local walk = global.walk
local walkSmoother = global.walkSmoother

--this is the counter yk (this is to increase walk counter if player is moving)
if pSpeed > 0.08 and M:abs(P:getYSpeed(player)) < 0.08 and P:isOnGround(player) then --get player speed and if its more than 0.08 and on the ground and stuff then start counter
    walk = walk + pSpeed * context.deltaTime * 30
    walkSmoother = walkSmoother + 0.1 * context.deltaTime * 30
else
    walkSmoother = walkSmoother - 0.1 * context.deltaTime * 30 --dont touch this plz
end

walkSmoother = M:clamp(walkSmoother, 0, 1)  --you need to clapm the walk smoother cuz it will go negative or too high if you dont,btw i should clamp walk too but im lazy lmao

local walk_val = (context.bl and walk) or (walk - 0.5 * 1.5) --basically 0.75 lol

if pHealth < 6 then
M:rotateX(mat, 3 * M:sin(walk_val) * walkSmoother, 0, -0.4, 0) --whole anim,sin for smoothing out movement starts from 0
M:rotateY(mat, -0.5 * M:cos(walk * 1.5) * walkSmoother * l, 0, -0.4, 0) --starts from 1
M:rotateZ(mat, 1 * M:cos(walk * 1.5) * walkSmoother * l, 0, -0.4, 0)
end

global.walk = walk
global.walkSmoother = walkSmoother